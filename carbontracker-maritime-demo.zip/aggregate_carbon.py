import pandas as pd
import glob

def aggregate_logs(log_dir_pattern="logs_*"):
    files = glob.glob(f"{log_dir_pattern}/*.csv")
    all_dfs = [pd.read_csv(f) for f in files]
    if not all_dfs:
        print("No logs found.")
        return
    df = pd.concat(all_dfs)
    df.to_csv("carbon_summary.csv", index=False)
    print("Saved summary to carbon_summary.csv")

if __name__ == "__main__":
    aggregate_logs()
