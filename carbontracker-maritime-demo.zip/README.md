# CarbonTracker Maritime Demo 🚢

This repo demonstrates how to measure the **carbon footprint of machine learning models** using [CarbonTracker](https://github.com/lfwa/carbontracker).  

It includes two demos:
1. **MNIST Training** – classic ML benchmark with carbon tracking.  
2. **Maritime ETA Prediction** – toy dataset predicting vessel ETA with carbon tracking.  

---

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Run MNIST demo
python train_mnist.py

# Run Maritime ETA demo
python train_maritime.py

# Summarize logs into CSV
python aggregate_carbon.py
```

---

## Repo Structure
```
carbontracker-maritime-demo/
│── README.md
│── requirements.txt
│── train_mnist.py         # ML demo
│── train_maritime.py      # Maritime ETA demo
│── aggregate_carbon.py    # Summarize carbon logs
│── data/                  # Maritime toy dataset (CSV)
```

---

## Ethical Note ⚠️
This repo is inspired by the original [CarbonTracker](https://github.com/lfwa/carbontracker).  
Forked/adapted for **educational + interview showcase purposes**.  
