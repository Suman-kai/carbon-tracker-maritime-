import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error
from carbontracker.tracker import CarbonTracker

# Load synthetic maritime dataset
data = pd.read_csv("data/maritime_toy.csv")

X = data[["Speed(knots)", "Distance(NM)", "CargoWeight(t)"]]
y = data["ETA(hours)"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

tracker = CarbonTracker(epochs=1, log_dir="logs_maritime")
tracker.epoch_start()

# Simple ML model (Linear Regression)
model = LinearRegression()
model.fit(X_train, y_train)
preds = model.predict(X_test)

tracker.epoch_end()
tracker.stop()

mae = mean_absolute_error(y_test, preds)
print(f"Maritime ETA MAE: {mae:.2f} hours")
